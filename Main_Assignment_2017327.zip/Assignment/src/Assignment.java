import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.stream.IntStream;

public class Assignment {
	String userID = "";
	String PIN = "";
	String accBalance ="";
	String answer = ""; //HOLDS INPUT FROM THE USER THROUGH ASKINGUSER METHOD
	String [] infoInFile = null; //HOLDS INFO FROM THE ACC FILE

	public Assignment(){
		welcomeMessage();
		login();
	
	}
//PRINTS MENU ON SCREEN 	
	public void menu() {
		System.out.println("1. Check Balance");
		System.out.println("2. Withdrawn");
		System.out.println("3. Change Password");
		System.out.println("4. Check Stocks");
		System.out.println("5. Logout");
		System.out.println("6. Bank Summary");
	}
	
// SHOWS MENU'S OPTIONS
	public void menuSelect() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				try {
			
			boolean valid = false;
			
			do {
		      System.out.println("Please enter a number: ");
			  String input = br.readLine();
			
				if(input.matches("[0-9]+")) {
				  	  valid = true;
				} else {
				 	valid = false;
				}
//PRINTS ACC BALANCE
				if(input.equals("1")) {
					System.out.println("�" + accBalance);
					anotherTrans();
					}
//GIVE THE OPTION TO WITHDRAW MONEY				
				else if(input.equals("2")) {
					System.out.println("How much do you want to withdraw?");
					askingUser();
					loadingFile(userID);
					
					int num1 = Integer.parseInt(infoInFile[2]);
					int num2 = Integer.parseInt(answer);
					infoInFile[2] = Integer.toString(num1 - num2);
					
				
					try {
						PrintWriter writer = new PrintWriter("C:\\Users\\RaphaelSmith\\Desktop\\" + userID + ".txt");
						
						for (int i = 0; i < 3 ; i++) {
							
							writer.println(infoInFile[i]);
							
						}
						
						writer.close(); // REMEMBER TO CLOSE YOUR WRITER. IF YOU DON'T, IT WON'T SAVE THE CHANGES.
						
					} catch (Exception e) {
					}
					System.out.println("Withdraw Successful");
					anotherTrans();
					}
										
					
				else if(input.equals("3")) {
					changePIN();
					anotherTrans();
				}	
//PRINT STOCK PRICES ON SCREEN				
				else if(input.equals("4")) {
					BufferedReader brStocks = new BufferedReader(new FileReader("C:\\Users\\RaphaelSmith\\Desktop\\Stocks.txt"));
					String stocksValue = brStocks.readLine();
					System.out.println("The Stock prices are " +stocksValue);
					anotherTrans();
				}
//LOGS OUT AND SENDS THE USER TO LOGIN 				
				else if (input.equals("5")) {
					System.out.println("Good Bye!");
					login();
				}
//SHOWS SPECIAL INFO OF ALL BANK ACCs				
				else if (input.equals("6")) {
					bankSummary();
					anotherTrans();
				}
				
				
			}while(valid == false);
			
		}catch(Exception e) { System.out.println("Error reading input");
		
		}
		
	
	
	}
		
	//PRINTS WELCOME WHEN PROGRAM RUNS
	public void welcomeMessage() {
		System.out.println("Welcome!");
	}
	
	//METHOD USED EVERYTIME YOU WANT TO ASK FOR USER INPUT
	public void login() {
		
		//##############################################
		//GET ID
		//##############################################
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String input= "";
		try {
			
			boolean valid = false;
			
			do {
		      System.out.println("Please enter your ID: ");
			  input = br.readLine();
			
				if(input.matches("[0-9]+")) {
				  	  valid = true;
				} else {
				 	valid = false;
				}
		
			}while(valid == false);
			
		}catch(Exception e) { System.out.println("Error reading input");}
	
		
		//##############################################
		//GET THE PIN
		//##############################################
		BufferedReader br2 = new BufferedReader(new InputStreamReader(System.in));
		String input2 = "";
		try {
			
			boolean valid = false;
			
			do {
		      System.out.println("Please enter your pin: ");
			  input2 = br2.readLine();
			
				if(input2.matches("[0-9]+")) {
				  	  valid = true;
				  } else {
				 	valid = false;
				}
			
			
			}while(valid == false);
			
		}catch(Exception e) { System.out.println("Error reading input");}
		
		try {
			BufferedReader br3 = new BufferedReader(new FileReader("C:\\Users\\RaphaelSmith\\Desktop\\"+input+".txt"));
			
			userID = br3.readLine();
			PIN = br3.readLine();
			accBalance= br3.readLine();
					
		if(input.equals(userID) && input2.equals(PIN)) {
			menu();
			menuSelect();
		}	else {
			login();
		}
			
			
		}catch(Exception e){}
	
	
	}
	
	public String askingUser() {
		BufferedReader br = new BufferedReader (new InputStreamReader (System.in));
		
		try {
			answer = br.readLine();
			
		}catch (Exception e) {
			
		}
		return answer;		

	}
//READS FILE AND STORES IN infoInFile ARRAY	
	public void loadingFile(String ID) {
		infoInFile = new String[3];
		try {
			BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\RaphaelSmith\\Desktop\\"+userID+".txt"));
			
			for(int i=0;i<3;i++) {
				infoInFile[i] = br.readLine();
			}
			br.close();
			
		}catch(Exception e) {
			System.out.println("File not found");
		}
	}

//ASK FOR INPUT AND STORES NEW PIN IN THE FILE
public void changePIN() {
	boolean valid = false;
	String newP1 = "";
	String newP2 = "";
	
	
	System.out.println("Please enter your new 4-digit PIN");
	newP1 = askingUser();
		if(newP1.matches("[0-9]+") && newP1.length() == 4) {
	  	valid = true;
		}
		else {
		 changePIN();
		}

	System.out.println("Confirm your new PIN");
	newP2 = askingUser();
										
	if(newP1.equals(newP2)) {
		System.out.println("PIN changed successfully!");
		loadingFile(userID);
		infoInFile[1] = newP2;
	
	
	try {
			PrintWriter writer = new PrintWriter("C:\\Users\\RaphaelSmith\\Desktop\\" + userID + ".txt"); // CHANGE FILE PATH
			
			for (int i = 0; i < 3 ; i++) {
				
				writer.println(infoInFile[i]);
				
			}
			
			writer.close(); 
		} catch (Exception e) {}
	}
	}	
	
//	###################################################################################################
//	#####################################  EXTRA  #####################################################
	public void bankSummary() {
		int accList[]= {100,200,300,400,500,600,700,800,900};
		String accExtract [] = new String[accList.length];
		int i = 0;
		try {
			
			for(i=0; i<accList.length; i++) {	
				BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\RaphaelSmith\\Desktop\\"+accList[i]+".txt"));

				br.readLine();
				br.readLine();
				accExtract [i]= br.readLine();


			}
		int smallAcc = 0;
		int medAcc = 0;
		int largeAcc = 0;
		int extraAcc = 0;
		int[] arr = strArrayToIntArray(accExtract);	
		int sum = IntStream.of(arr).sum();
	
			for(i=0;i<arr.length;i++) {
				if (arr[i]<100) {
					smallAcc = smallAcc + 1;
				}
				else if (arr[i]>100 && arr[i]<=200) {
					medAcc = medAcc + 1;
				}
				else if (arr[i]>200 && arr[i]<=300) {
					largeAcc = largeAcc + 1;
				}
				else if (arr[i]>300) {
					extraAcc = extraAcc +1;
				}
			}
		System.out.println(smallAcc + " small accounts");
		System.out.println(medAcc + " medium accounts");
		System.out.println(largeAcc + " large accounts");
		System.out.println(extraAcc + " extra large accounts");
		
		System.out.println("The amount of money of all bank accounts is " + sum);
		
		
		}catch (Exception e) {
			System.out.println("Error reading account files");
		}
	}
public void anotherTrans() {
	System.out.println("Do another transaction? (Y/N)");
	askingUser();
try {
boolean value = false;
do{
	if(answer.equals("Y") || answer.equals("y")){
		menu();
		menuSelect();
		value = true;
	}
	else if(answer.equals("N") || answer.equals("n")) {
		login();
	}
  } while(value = false);
}catch(Exception e) { System.out.println("Error reading input");}	
}
//CALL THIS EVERYTIME YOU NEED TO CONVERT AN STRING ARRAY TO INT
	public static int[] strArrayToIntArray(String[] a){
	    int[] b = new int[a.length];
	    for (int i = 0; i < a.length; i++) {
	        b[i] = Integer.parseInt(a[i]);
	    }

	    return b;
	}
	
	
	//MAIN METHOD
 	public static void main(String[] args) {
		new Assignment();
	}

}
